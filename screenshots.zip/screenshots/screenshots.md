#### 實驗開始畫面
![alt text](start.png)

#### 第一部分

![alt text](phase1-1.png)

- 預測正確
![alt text](correct.png)

- 預測錯誤
![alt text](false.png)

- 按下next後會進入等待畫面 (等待所有受試者)
![alt text](wait1.png)

#### 第二部分

- 朗讀實驗說明
![alt text](start2.png)

##### 額外說明回合畫面
![alt text](11-20.png)
![alt text](warning.png)
![alt text](choice_made.png)
![alt text](reasoning.png)
![alt text](warning2.png)
![alt text](payoff2.png)
![alt text](payoff2-2.png)

#### 第三部分
![alt text](start3.png)
![alt text](p-beauty.png)
![alt text](warning3.png)
![alt text](payoff3.png)
![alt text](payoff3-2.png)

#### 生成/判斷理由
![alt text](phase_AI.png)
![alt text](call_api.png)


#### 第四部分
![alt text](start4.png)
![alt text](prediction.png)
![alt text](result.png)
![alt text](ai_result.png)
![alt text](ai_result2.png)

![alt text](final_payoff.png)
![alt text](questionaire.png)